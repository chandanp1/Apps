/*This code is for FruitBasket Application
#This application accepts csv as input file and provides result based on that 
# contact details : ckajay84@gmail.com Mobile: 08939413251
*/

import java.io.*;
import java.util.Arrays;
import java.util.List;
import java.util.HashMap;
import java.util.Scanner;


//this class is for initialising arrays containing Fruits details.

class Fruits
{
    // Instance Variables
    String type;
    String characteristic1;
    int age;
    String characteristic2;
 
    // Constructor Declaration of Class
    public Fruits(String type, 
                   int age, String char1, String char2)
    {
        this.type = type;
        this.age = age;
        this.characteristic1 = char1;
        this.characteristic2 = char2;
    }
}

//This class declered for functions which is required for application

class fruityFunctions
{
    Fruits[] f1;
    
    // function 1 gives total count of fruits in FruitBasket
    void countAll(Fruits[] f){
        System.out.println("");
        System.out.println("Total number of fruit:");
        System.out.println(f.length);
    }
     // function 2 gives Distinct count of fruits in FruitBasket based on type of fruit
    void printDistinct(Fruits[] f){
        int len = f.length;
        int count =0;
        for (int i = 0; i < len; i++) 
        { 
            int j =0; 
            for (j = 0; j < i; j++) {
                if ((f[i].type).equals(f[j].type)){ 
                    break; 
                }
            }    
            if (i == j){
                count++;
            }
        }
        System.out.println("");
        System.out.println("Total types of fruit:");
        System.out.println(count);
    }
    // function 3 gives name and age of oldest fruits in FruitBasket based on age.
    void oldestFruit(Fruits[] f){
         int max1=0;
         int j=0;
         int count=0;
         int[] pos = new int[4];
         
         max1 = f[0].age;
        for(int i=1 ; i< f.length; i++ ){
            if(max1 < f[i].age){
               max1 = f[i].age;
               pos[j] = i;
            }
        }
        for(int i=0; i<f.length; i++){
            if(max1==f[i].age){
                pos[j] = i;
                j++;
            }   
        }
        System.out.println("Oldest fruit & age:");
        for(int i=0; i<j; i++){
            count=pos[i];
            System.out.println(f[count].type+" : "+f[count].age);
        }
    }
    // function 4 gives Count of all fruits grouped by fruit types in descending order
    void printfruitsType(Fruits[] f)
    {
        int len= f.length;
        String[] s;
        String[] s2;
        int count = 0;
        int[] num;
        int[] num2;
        
        // Pick all elements one by one 
        for (int i = 0; i < len; i++) 
        { 
            // count of distinct fuuit to initialise the array
            int j =0; 
            for (j = 0; j < i; j++) {
                if ((f[i].type).equals(f[j].type)){ 
                    break; 
                }
            }    
            if (i == j){
                count++;
            }
        }
        
        s = new String[count];
        s2 = new String[count];
        num = new int[count];
        num2 = new int[count];
        int count2=0;
        
        // nested loops to calculate Count of all fruits grouped by fruit types in descending order
        for (int i = 0; i < len; i++) 
        { 
            int j =0; 
            for (j = 0; j < i; j++) {
                if ((f[i].type).equals(f[j].type)){ 
                    break; 
                }
               
            }    
            if (i == j){
                s[count2]= f[i].type;
                count2++;
                
            }
        }
        for(int i=0; i<count; i++){
            num[i] = 0;
            for(int j=0; j<len; j++){
                if ((s[i]).equals(f[j].type)){ 
                    num[i]++;
                }
            }
        }
        for(int i=0; i<count; i++){
            num2[i]=num[i];
            s2[i]=s[i];
            for(int j=i+1; j<count; j++){
                if(num[i]<num[j]){
                    num2[i] = num[j];
                    s2[i]=s[j];
                }
            }
        }
        // printing the results
        System.out.println("");
        System.out.println(" The number of each type of fruit in descending order:");
        for(int i=0; i<count; i++){
           System.out.println( s2[i]+" : "+num2[i]); 
        }
    } 
    
    //function 5 Count of all fruits grouped by fruit type and all characteristics in descending order
    void grpByCharacteristics(Fruits[] f)
    {
        Fruits[] f1 = f;
        int len= f.length;
        String[] s;
        String[] s2;
        
        int[] num;
        int[] num2;
        System.out.println("");
        System.out.println("The various characteristics (count, color, shape, etc.) of each fruit by type:");
        
        //nested loop to sort fruits and count based on characterstics 
        
        for(int i=0; i<len; i++){
            int count = 1;
            String fruit1 = f1[i].type;
            
            for(int j=i+1; j<len ; j++){
                if(fruit1.equals(f1[j].type) && (f1[i].characteristic1).equals((f1[j].characteristic1)) && (f1[i].characteristic2).equals(f1[j].characteristic2)){
                count++;
                for(int k=j; k< len-1; k++){
                        f1[k]=f1[k+1];
                    }
                    len--;
                    j=j-1;
                }
            }
            
            System.out.println(count+"  "+fruit1+" : "+f1[i].characteristic1+" , "+f1[i].characteristic2);
        }
        
    }  
}




//Main Class to initialise Application
public class FruitBasket1  {

    public static void main(String[] args) throws IOException,ArrayIndexOutOfBoundsException {
        String row;
        
        // Class array to read lines of CSV file 
        Fruits[] arr;
        int j=0,i=0;
        int var;
        // Object creation of class containing functions for the application
        fruityFunctions f = new fruityFunctions();
        
        
         //Get input file from user
        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
        System.out.println("Enter CSV file with fruites details: ");
        
        //reading console input for Valid file name
        String  fileName= myObj.nextLine();
        
        
        try{
            // reading CSV File to count number of rows in file to initialise Fruit class Array
            FileReader fr = new FileReader(fileName);    
            BufferedReader csvReader = new BufferedReader(fr);
            while ((row = csvReader.readLine()) != null) {
              j+=1;
            }
            csvReader.close();
            arr = new Fruits[j-2];
            // reading CSV File to  perform operation
            
            FileReader fr1 = new FileReader(fileName);    
            BufferedReader csvReader1 = new BufferedReader(fr1);
            try{
            while ((row = csvReader1.readLine()) != null) {
                String[] data = row.split(",");
                if(i>0 ){
                var = Integer.parseInt(data[1]);
                //System.out.println(var);
                arr[i-1] = new Fruits(data[0],var,data[2],data[3]);
                }
                i+=1;
            }
            }catch(ArrayIndexOutOfBoundsException e){}
            
            // function call 
            f.countAll(arr);
            System.out.println("");
            f.printDistinct(arr);
            System.out.println("");
            f.oldestFruit(arr);
            System.out.println("");
            f.printfruitsType(arr);
            System.out.println("");
            f.grpByCharacteristics(arr);
            
            //closing Buffer reader.
            csvReader1.close();
        }catch(FileNotFoundException e){
            //incase wrong file path provided
            System.out.print("Please Enter Valid file Name");  
        }
        
        
    }

}
