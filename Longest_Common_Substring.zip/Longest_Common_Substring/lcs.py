#!/usr/bin/env python3
# This Script creates API for Longest Common Substring
# input is given through html page called lcs_input.html
# This script accepts input as JSON into html textbox.
#Contact Details: ckajay184@gmail.com , Mob: 08939413251


import json
from flask import Flask, redirect, url_for, request, jsonify

app = Flask(__name__)
app.config["DEBUG"] = True

#Function for LCM of 2 Srings

def lcs(S,T):
    m = len(S)
    n = len(T)
    counter = [[0]*(n+1) for x in range(m+1)]
    longest = 0
    lcs_set = set()
    for i in range(m):
        for j in range(n):
            if S[i] == T[j]:
                c = counter[i][j] + 1
                counter[i+1][j+1] = c
                if c > longest:
                    lcs_set = set()
                    longest = c
                    lcs_set.add(S[i-c+1:i+1])
                elif c == longest:
                    lcs_set.add(S[i-c+1:i+1])

    return lcs_set


## API URI Creation andreturning of value
   
@app.route('/lcs',methods = ['POST', 'GET'])
def login():
   if request.method == 'POST':
      json_form = request.form['nm']  # recieving values from html form
      if json_form:
         try:
            data=json.loads(json_form)   # loading into JSON
            str1=data["setOfStrings"][0]["value"]
            str2=data["setOfStrings"][1]["value"]
            str3= data["setOfStrings"][2]["value"]
            ret = lcs(str1,str2)  # function call for LCS of 2 string
            ret1= list(ret)       # Converting set value to list to proceed with furtherLCS
      
            len1=len(ret1)
            length=0
            s1=''
            print(len1)
            i=0
            while i <len1:
               ret2 = lcs(ret1[i],str3)    # Calling LCS for 2nd time for third string.
               i+=1
               j=0
               if ret2:
                  ret3 = list(ret2)
                  len2= len(ret3)
                  while j<len2:
                     if(len(ret3[j])>length):
                        length=len(ret3[j])
                        s1=ret3[j]           # Storing result to return to API
                     j+=1
         
      
            if s1 =='':
               return jsonify(value="there is no common substring")   # return "_" if there is no common substring
            else:
               return jsonify(value=s1)     # Returning Common Substring to API Call
         except:
            return jsonify(message="<please enter valid JSON input format>")  # returning To API if format is not acceptible
      else:
         return jsonify(message="<please enter  JSON input>")    # in case empty form submittion 

if __name__ == '__main__':
   app.run(debug = True)
